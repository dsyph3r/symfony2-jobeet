<?php

namespace SfTuts\JobeetBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class SfTutsJobeetBundle extends Bundle
{
}
